// aha_crypto.v  -- AUTO-GENERATED from the recovered bitstream model.
//
// 4-round PRESENT-like SPN over a 32-bit block, SPI peripheral interface.
//   x = Ain(P) ^ KEY
//   repeat 3:  x = Mb(SubBytes(x)) ^ KEY
//   C = Md(SubBytes(x))                     // final round key = 0
// SubBytes applies one 8-bit bijective S-box to each byte lane (lane0 = MSB).
//
// Driven by the documented SPI protocol this module is bit-exact to the
// original bitstream (see verify_equivalence.py).
//
`default_nettype none
`timescale 1ns/1ps


module aha_crypto (
    input  wire SCK,        // unified system + SPI clock (<=1 MHz)
    input  wire RST_N,      // synchronous active-low reset
    input  wire MOSI,       // serial data in
    output reg  MISO,       // serial data out (registered)
    input  wire NORM_CS_N,  // active-low chip select / shift enable
    input  wire START,      // start a crypto operation
    input  wire ENC_DEC,    // 0 = encrypt, 1 = decrypt
    output wire BUSY,       // high while the core is processing (4 cycles)
    output wire ICE_LED     // visual mirror of BUSY
);
  localparam [31:0] KEY = 32'hD81E0247;

  reg  [31:0] shreg;   // SPI shift register, also holds the result for read-out
  reg  [31:0] state;   // round state
  reg  [2:0]  cnt;     // 0 = idle, 1..4 = round progress
  reg         busy;

  assign BUSY    = busy;
  assign ICE_LED = busy;


  // ---- S-box ROM and inverse ----
  function [7:0] sbox;
    input [7:0] a;
    case (a)
      8'h00: sbox = 8'h39;
      8'h01: sbox = 8'h3F;
      8'h02: sbox = 8'hBA;
      8'h03: sbox = 8'h7D;
      8'h04: sbox = 8'h22;
      8'h05: sbox = 8'h3D;
      8'h06: sbox = 8'hFE;
      8'h07: sbox = 8'hF1;
      8'h08: sbox = 8'hD8;
      8'h09: sbox = 8'hC9;
      8'h0A: sbox = 8'hFA;
      8'h0B: sbox = 8'h1D;
      8'h0C: sbox = 8'hE5;
      8'h0D: sbox = 8'hB0;
      8'h0E: sbox = 8'hC6;
      8'h0F: sbox = 8'h3A;
      8'h10: sbox = 8'hB7;
      8'h11: sbox = 8'h93;
      8'h12: sbox = 8'h36;
      8'h13: sbox = 8'hBF;
      8'h14: sbox = 8'h26;
      8'h15: sbox = 8'hAD;
      8'h16: sbox = 8'h2B;
      8'h17: sbox = 8'h23;
      8'h18: sbox = 8'h04;
      8'h19: sbox = 8'h31;
      8'h1A: sbox = 8'h42;
      8'h1B: sbox = 8'h05;
      8'h1C: sbox = 8'h15;
      8'h1D: sbox = 8'h80;
      8'h1E: sbox = 8'hF9;
      8'h1F: sbox = 8'hB2;
      8'h20: sbox = 8'h41;
      8'h21: sbox = 8'h64;
      8'h22: sbox = 8'h53;
      8'h23: sbox = 8'h5A;
      8'h24: sbox = 8'h1A;
      8'h25: sbox = 8'h9E;
      8'h26: sbox = 8'h61;
      8'h27: sbox = 8'h75;
      8'h28: sbox = 8'h1B;
      8'h29: sbox = 8'h00;
      8'h2A: sbox = 8'h20;
      8'h2B: sbox = 8'hA3;
      8'h2C: sbox = 8'h78;
      8'h2D: sbox = 8'hF6;
      8'h2E: sbox = 8'h58;
      8'h2F: sbox = 8'h4A;
      8'h30: sbox = 8'h8A;
      8'h31: sbox = 8'hF0;
      8'h32: sbox = 8'h19;
      8'h33: sbox = 8'h33;
      8'h34: sbox = 8'h0D;
      8'h35: sbox = 8'h10;
      8'h36: sbox = 8'h0A;
      8'h37: sbox = 8'hD7;
      8'h38: sbox = 8'h0B;
      8'h39: sbox = 8'h08;
      8'h3A: sbox = 8'h92;
      8'h3B: sbox = 8'h62;
      8'h3C: sbox = 8'hE6;
      8'h3D: sbox = 8'hDA;
      8'h3E: sbox = 8'h02;
      8'h3F: sbox = 8'hBB;
      8'h40: sbox = 8'hCD;
      8'h41: sbox = 8'h13;
      8'h42: sbox = 8'h5F;
      8'h43: sbox = 8'h0C;
      8'h44: sbox = 8'h8C;
      8'h45: sbox = 8'h7E;
      8'h46: sbox = 8'h2C;
      8'h47: sbox = 8'h43;
      8'h48: sbox = 8'h28;
      8'h49: sbox = 8'h5D;
      8'h4A: sbox = 8'h30;
      8'h4B: sbox = 8'h82;
      8'h4C: sbox = 8'h1C;
      8'h4D: sbox = 8'hE2;
      8'h4E: sbox = 8'hDE;
      8'h4F: sbox = 8'h51;
      8'h50: sbox = 8'hA8;
      8'h51: sbox = 8'h72;
      8'h52: sbox = 8'h49;
      8'h53: sbox = 8'h24;
      8'h54: sbox = 8'h98;
      8'h55: sbox = 8'hE4;
      8'h56: sbox = 8'h83;
      8'h57: sbox = 8'hAC;
      8'h58: sbox = 8'hBD;
      8'h59: sbox = 8'h37;
      8'h5A: sbox = 8'hC5;
      8'h5B: sbox = 8'h5C;
      8'h5C: sbox = 8'h6C;
      8'h5D: sbox = 8'hAE;
      8'h5E: sbox = 8'h2D;
      8'h5F: sbox = 8'hF4;
      8'h60: sbox = 8'hF2;
      8'h61: sbox = 8'h25;
      8'h62: sbox = 8'h46;
      8'h63: sbox = 8'hA6;
      8'h64: sbox = 8'hE8;
      8'h65: sbox = 8'h2E;
      8'h66: sbox = 8'h59;
      8'h67: sbox = 8'hD1;
      8'h68: sbox = 8'h2A;
      8'h69: sbox = 8'hA7;
      8'h6A: sbox = 8'h48;
      8'h6B: sbox = 8'hBE;
      8'h6C: sbox = 8'h29;
      8'h6D: sbox = 8'h1F;
      8'h6E: sbox = 8'h94;
      8'h6F: sbox = 8'h47;
      8'h70: sbox = 8'hA9;
      8'h71: sbox = 8'hC2;
      8'h72: sbox = 8'h69;
      8'h73: sbox = 8'hD4;
      8'h74: sbox = 8'hD3;
      8'h75: sbox = 8'h95;
      8'h76: sbox = 8'hDC;
      8'h77: sbox = 8'h60;
      8'h78: sbox = 8'hC4;
      8'h79: sbox = 8'hC1;
      8'h7A: sbox = 8'hF7;
      8'h7B: sbox = 8'h18;
      8'h7C: sbox = 8'h09;
      8'h7D: sbox = 8'h65;
      8'h7E: sbox = 8'hA2;
      8'h7F: sbox = 8'hF3;
      8'h80: sbox = 8'h6E;
      8'h81: sbox = 8'h7B;
      8'h82: sbox = 8'h79;
      8'h83: sbox = 8'h8D;
      8'h84: sbox = 8'h01;
      8'h85: sbox = 8'h71;
      8'h86: sbox = 8'h9F;
      8'h87: sbox = 8'h3E;
      8'h88: sbox = 8'h90;
      8'h89: sbox = 8'h6F;
      8'h8A: sbox = 8'h4B;
      8'h8B: sbox = 8'hAA;
      8'h8C: sbox = 8'h8E;
      8'h8D: sbox = 8'hF5;
      8'h8E: sbox = 8'hA4;
      8'h8F: sbox = 8'h88;
      8'h90: sbox = 8'hEF;
      8'h91: sbox = 8'h34;
      8'h92: sbox = 8'h77;
      8'h93: sbox = 8'hCC;
      8'h94: sbox = 8'hA5;
      8'h95: sbox = 8'hAB;
      8'h96: sbox = 8'hCA;
      8'h97: sbox = 8'h07;
      8'h98: sbox = 8'h9D;
      8'h99: sbox = 8'h99;
      8'h9A: sbox = 8'h96;
      8'h9B: sbox = 8'hD2;
      8'h9C: sbox = 8'h12;
      8'h9D: sbox = 8'hB8;
      8'h9E: sbox = 8'h35;
      8'h9F: sbox = 8'h2F;
      8'hA0: sbox = 8'h91;
      8'hA1: sbox = 8'h52;
      8'hA2: sbox = 8'h7C;
      8'hA3: sbox = 8'hA0;
      8'hA4: sbox = 8'h73;
      8'hA5: sbox = 8'hB3;
      8'hA6: sbox = 8'hB9;
      8'hA7: sbox = 8'h84;
      8'hA8: sbox = 8'h8B;
      8'hA9: sbox = 8'hED;
      8'hAA: sbox = 8'hEE;
      8'hAB: sbox = 8'h5B;
      8'hAC: sbox = 8'hD9;
      8'hAD: sbox = 8'h63;
      8'hAE: sbox = 8'h4C;
      8'hAF: sbox = 8'hDD;
      8'hB0: sbox = 8'hFD;
      8'hB1: sbox = 8'hFB;
      8'hB2: sbox = 8'h4D;
      8'hB3: sbox = 8'h85;
      8'hB4: sbox = 8'hEB;
      8'hB5: sbox = 8'h7F;
      8'hB6: sbox = 8'h66;
      8'hB7: sbox = 8'hE0;
      8'hB8: sbox = 8'hB1;
      8'hB9: sbox = 8'hD5;
      8'hBA: sbox = 8'hC7;
      8'hBB: sbox = 8'hAF;
      8'hBC: sbox = 8'hB6;
      8'hBD: sbox = 8'h21;
      8'hBE: sbox = 8'hFF;
      8'hBF: sbox = 8'h9A;
      8'hC0: sbox = 8'h44;
      8'hC1: sbox = 8'hEC;
      8'hC2: sbox = 8'h97;
      8'hC3: sbox = 8'h17;
      8'hC4: sbox = 8'hB5;
      8'hC5: sbox = 8'h67;
      8'hC6: sbox = 8'h4F;
      8'hC7: sbox = 8'h3B;
      8'hC8: sbox = 8'h81;
      8'hC9: sbox = 8'hCE;
      8'hCA: sbox = 8'h70;
      8'hCB: sbox = 8'hC0;
      8'hCC: sbox = 8'hFC;
      8'hCD: sbox = 8'h06;
      8'hCE: sbox = 8'h5E;
      8'hCF: sbox = 8'hDB;
      8'hD0: sbox = 8'h32;
      8'hD1: sbox = 8'h50;
      8'hD2: sbox = 8'h14;
      8'hD3: sbox = 8'h4E;
      8'hD4: sbox = 8'h9B;
      8'hD5: sbox = 8'h38;
      8'hD6: sbox = 8'h87;
      8'hD7: sbox = 8'h6B;
      8'hD8: sbox = 8'hC8;
      8'hD9: sbox = 8'h6D;
      8'hDA: sbox = 8'h8F;
      8'hDB: sbox = 8'hE1;
      8'hDC: sbox = 8'h1E;
      8'hDD: sbox = 8'hF8;
      8'hDE: sbox = 8'h7A;
      8'hDF: sbox = 8'h40;
      8'hE0: sbox = 8'h6A;
      8'hE1: sbox = 8'h74;
      8'hE2: sbox = 8'hB4;
      8'hE3: sbox = 8'h9C;
      8'hE4: sbox = 8'hCF;
      8'hE5: sbox = 8'h57;
      8'hE6: sbox = 8'hE7;
      8'hE7: sbox = 8'hD0;
      8'hE8: sbox = 8'h76;
      8'hE9: sbox = 8'h3C;
      8'hEA: sbox = 8'h11;
      8'hEB: sbox = 8'h54;
      8'hEC: sbox = 8'h27;
      8'hED: sbox = 8'hE3;
      8'hEE: sbox = 8'h89;
      8'hEF: sbox = 8'hD6;
      8'hF0: sbox = 8'hEA;
      8'hF1: sbox = 8'h03;
      8'hF2: sbox = 8'hCB;
      8'hF3: sbox = 8'h86;
      8'hF4: sbox = 8'h56;
      8'hF5: sbox = 8'hE9;
      8'hF6: sbox = 8'h0F;
      8'hF7: sbox = 8'hDF;
      8'hF8: sbox = 8'hA1;
      8'hF9: sbox = 8'h45;
      8'hFA: sbox = 8'hBC;
      8'hFB: sbox = 8'h68;
      8'hFC: sbox = 8'hC3;
      8'hFD: sbox = 8'h55;
      8'hFE: sbox = 8'h0E;
      8'hFF: sbox = 8'h16;
      default: sbox = 8'h00;
    endcase
  endfunction
  function [7:0] isbox;
    input [7:0] a;
    case (a)
      8'h00: isbox = 8'h29;
      8'h01: isbox = 8'h84;
      8'h02: isbox = 8'h3E;
      8'h03: isbox = 8'hF1;
      8'h04: isbox = 8'h18;
      8'h05: isbox = 8'h1B;
      8'h06: isbox = 8'hCD;
      8'h07: isbox = 8'h97;
      8'h08: isbox = 8'h39;
      8'h09: isbox = 8'h7C;
      8'h0A: isbox = 8'h36;
      8'h0B: isbox = 8'h38;
      8'h0C: isbox = 8'h43;
      8'h0D: isbox = 8'h34;
      8'h0E: isbox = 8'hFE;
      8'h0F: isbox = 8'hF6;
      8'h10: isbox = 8'h35;
      8'h11: isbox = 8'hEA;
      8'h12: isbox = 8'h9C;
      8'h13: isbox = 8'h41;
      8'h14: isbox = 8'hD2;
      8'h15: isbox = 8'h1C;
      8'h16: isbox = 8'hFF;
      8'h17: isbox = 8'hC3;
      8'h18: isbox = 8'h7B;
      8'h19: isbox = 8'h32;
      8'h1A: isbox = 8'h24;
      8'h1B: isbox = 8'h28;
      8'h1C: isbox = 8'h4C;
      8'h1D: isbox = 8'h0B;
      8'h1E: isbox = 8'hDC;
      8'h1F: isbox = 8'h6D;
      8'h20: isbox = 8'h2A;
      8'h21: isbox = 8'hBD;
      8'h22: isbox = 8'h04;
      8'h23: isbox = 8'h17;
      8'h24: isbox = 8'h53;
      8'h25: isbox = 8'h61;
      8'h26: isbox = 8'h14;
      8'h27: isbox = 8'hEC;
      8'h28: isbox = 8'h48;
      8'h29: isbox = 8'h6C;
      8'h2A: isbox = 8'h68;
      8'h2B: isbox = 8'h16;
      8'h2C: isbox = 8'h46;
      8'h2D: isbox = 8'h5E;
      8'h2E: isbox = 8'h65;
      8'h2F: isbox = 8'h9F;
      8'h30: isbox = 8'h4A;
      8'h31: isbox = 8'h19;
      8'h32: isbox = 8'hD0;
      8'h33: isbox = 8'h33;
      8'h34: isbox = 8'h91;
      8'h35: isbox = 8'h9E;
      8'h36: isbox = 8'h12;
      8'h37: isbox = 8'h59;
      8'h38: isbox = 8'hD5;
      8'h39: isbox = 8'h00;
      8'h3A: isbox = 8'h0F;
      8'h3B: isbox = 8'hC7;
      8'h3C: isbox = 8'hE9;
      8'h3D: isbox = 8'h05;
      8'h3E: isbox = 8'h87;
      8'h3F: isbox = 8'h01;
      8'h40: isbox = 8'hDF;
      8'h41: isbox = 8'h20;
      8'h42: isbox = 8'h1A;
      8'h43: isbox = 8'h47;
      8'h44: isbox = 8'hC0;
      8'h45: isbox = 8'hF9;
      8'h46: isbox = 8'h62;
      8'h47: isbox = 8'h6F;
      8'h48: isbox = 8'h6A;
      8'h49: isbox = 8'h52;
      8'h4A: isbox = 8'h2F;
      8'h4B: isbox = 8'h8A;
      8'h4C: isbox = 8'hAE;
      8'h4D: isbox = 8'hB2;
      8'h4E: isbox = 8'hD3;
      8'h4F: isbox = 8'hC6;
      8'h50: isbox = 8'hD1;
      8'h51: isbox = 8'h4F;
      8'h52: isbox = 8'hA1;
      8'h53: isbox = 8'h22;
      8'h54: isbox = 8'hEB;
      8'h55: isbox = 8'hFD;
      8'h56: isbox = 8'hF4;
      8'h57: isbox = 8'hE5;
      8'h58: isbox = 8'h2E;
      8'h59: isbox = 8'h66;
      8'h5A: isbox = 8'h23;
      8'h5B: isbox = 8'hAB;
      8'h5C: isbox = 8'h5B;
      8'h5D: isbox = 8'h49;
      8'h5E: isbox = 8'hCE;
      8'h5F: isbox = 8'h42;
      8'h60: isbox = 8'h77;
      8'h61: isbox = 8'h26;
      8'h62: isbox = 8'h3B;
      8'h63: isbox = 8'hAD;
      8'h64: isbox = 8'h21;
      8'h65: isbox = 8'h7D;
      8'h66: isbox = 8'hB6;
      8'h67: isbox = 8'hC5;
      8'h68: isbox = 8'hFB;
      8'h69: isbox = 8'h72;
      8'h6A: isbox = 8'hE0;
      8'h6B: isbox = 8'hD7;
      8'h6C: isbox = 8'h5C;
      8'h6D: isbox = 8'hD9;
      8'h6E: isbox = 8'h80;
      8'h6F: isbox = 8'h89;
      8'h70: isbox = 8'hCA;
      8'h71: isbox = 8'h85;
      8'h72: isbox = 8'h51;
      8'h73: isbox = 8'hA4;
      8'h74: isbox = 8'hE1;
      8'h75: isbox = 8'h27;
      8'h76: isbox = 8'hE8;
      8'h77: isbox = 8'h92;
      8'h78: isbox = 8'h2C;
      8'h79: isbox = 8'h82;
      8'h7A: isbox = 8'hDE;
      8'h7B: isbox = 8'h81;
      8'h7C: isbox = 8'hA2;
      8'h7D: isbox = 8'h03;
      8'h7E: isbox = 8'h45;
      8'h7F: isbox = 8'hB5;
      8'h80: isbox = 8'h1D;
      8'h81: isbox = 8'hC8;
      8'h82: isbox = 8'h4B;
      8'h83: isbox = 8'h56;
      8'h84: isbox = 8'hA7;
      8'h85: isbox = 8'hB3;
      8'h86: isbox = 8'hF3;
      8'h87: isbox = 8'hD6;
      8'h88: isbox = 8'h8F;
      8'h89: isbox = 8'hEE;
      8'h8A: isbox = 8'h30;
      8'h8B: isbox = 8'hA8;
      8'h8C: isbox = 8'h44;
      8'h8D: isbox = 8'h83;
      8'h8E: isbox = 8'h8C;
      8'h8F: isbox = 8'hDA;
      8'h90: isbox = 8'h88;
      8'h91: isbox = 8'hA0;
      8'h92: isbox = 8'h3A;
      8'h93: isbox = 8'h11;
      8'h94: isbox = 8'h6E;
      8'h95: isbox = 8'h75;
      8'h96: isbox = 8'h9A;
      8'h97: isbox = 8'hC2;
      8'h98: isbox = 8'h54;
      8'h99: isbox = 8'h99;
      8'h9A: isbox = 8'hBF;
      8'h9B: isbox = 8'hD4;
      8'h9C: isbox = 8'hE3;
      8'h9D: isbox = 8'h98;
      8'h9E: isbox = 8'h25;
      8'h9F: isbox = 8'h86;
      8'hA0: isbox = 8'hA3;
      8'hA1: isbox = 8'hF8;
      8'hA2: isbox = 8'h7E;
      8'hA3: isbox = 8'h2B;
      8'hA4: isbox = 8'h8E;
      8'hA5: isbox = 8'h94;
      8'hA6: isbox = 8'h63;
      8'hA7: isbox = 8'h69;
      8'hA8: isbox = 8'h50;
      8'hA9: isbox = 8'h70;
      8'hAA: isbox = 8'h8B;
      8'hAB: isbox = 8'h95;
      8'hAC: isbox = 8'h57;
      8'hAD: isbox = 8'h15;
      8'hAE: isbox = 8'h5D;
      8'hAF: isbox = 8'hBB;
      8'hB0: isbox = 8'h0D;
      8'hB1: isbox = 8'hB8;
      8'hB2: isbox = 8'h1F;
      8'hB3: isbox = 8'hA5;
      8'hB4: isbox = 8'hE2;
      8'hB5: isbox = 8'hC4;
      8'hB6: isbox = 8'hBC;
      8'hB7: isbox = 8'h10;
      8'hB8: isbox = 8'h9D;
      8'hB9: isbox = 8'hA6;
      8'hBA: isbox = 8'h02;
      8'hBB: isbox = 8'h3F;
      8'hBC: isbox = 8'hFA;
      8'hBD: isbox = 8'h58;
      8'hBE: isbox = 8'h6B;
      8'hBF: isbox = 8'h13;
      8'hC0: isbox = 8'hCB;
      8'hC1: isbox = 8'h79;
      8'hC2: isbox = 8'h71;
      8'hC3: isbox = 8'hFC;
      8'hC4: isbox = 8'h78;
      8'hC5: isbox = 8'h5A;
      8'hC6: isbox = 8'h0E;
      8'hC7: isbox = 8'hBA;
      8'hC8: isbox = 8'hD8;
      8'hC9: isbox = 8'h09;
      8'hCA: isbox = 8'h96;
      8'hCB: isbox = 8'hF2;
      8'hCC: isbox = 8'h93;
      8'hCD: isbox = 8'h40;
      8'hCE: isbox = 8'hC9;
      8'hCF: isbox = 8'hE4;
      8'hD0: isbox = 8'hE7;
      8'hD1: isbox = 8'h67;
      8'hD2: isbox = 8'h9B;
      8'hD3: isbox = 8'h74;
      8'hD4: isbox = 8'h73;
      8'hD5: isbox = 8'hB9;
      8'hD6: isbox = 8'hEF;
      8'hD7: isbox = 8'h37;
      8'hD8: isbox = 8'h08;
      8'hD9: isbox = 8'hAC;
      8'hDA: isbox = 8'h3D;
      8'hDB: isbox = 8'hCF;
      8'hDC: isbox = 8'h76;
      8'hDD: isbox = 8'hAF;
      8'hDE: isbox = 8'h4E;
      8'hDF: isbox = 8'hF7;
      8'hE0: isbox = 8'hB7;
      8'hE1: isbox = 8'hDB;
      8'hE2: isbox = 8'h4D;
      8'hE3: isbox = 8'hED;
      8'hE4: isbox = 8'h55;
      8'hE5: isbox = 8'h0C;
      8'hE6: isbox = 8'h3C;
      8'hE7: isbox = 8'hE6;
      8'hE8: isbox = 8'h64;
      8'hE9: isbox = 8'hF5;
      8'hEA: isbox = 8'hF0;
      8'hEB: isbox = 8'hB4;
      8'hEC: isbox = 8'hC1;
      8'hED: isbox = 8'hA9;
      8'hEE: isbox = 8'hAA;
      8'hEF: isbox = 8'h90;
      8'hF0: isbox = 8'h31;
      8'hF1: isbox = 8'h07;
      8'hF2: isbox = 8'h60;
      8'hF3: isbox = 8'h7F;
      8'hF4: isbox = 8'h5F;
      8'hF5: isbox = 8'h8D;
      8'hF6: isbox = 8'h2D;
      8'hF7: isbox = 8'h7A;
      8'hF8: isbox = 8'hDD;
      8'hF9: isbox = 8'h1E;
      8'hFA: isbox = 8'h0A;
      8'hFB: isbox = 8'hB1;
      8'hFC: isbox = 8'hCC;
      8'hFD: isbox = 8'hB0;
      8'hFE: isbox = 8'h06;
      8'hFF: isbox = 8'hBE;
      default: isbox = 8'h00;
    endcase
  endfunction

  // ---- bit permutations (output bit i = input bit perm[i]) ----
  function [31:0] perm_ain;
    input [31:0] x;
    begin
      perm_ain[ 0] = x[25];
      perm_ain[ 1] = x[26];
      perm_ain[ 2] = x[27];
      perm_ain[ 3] = x[28];
      perm_ain[ 4] = x[29];
      perm_ain[ 5] = x[30];
      perm_ain[ 6] = x[31];
      perm_ain[ 7] = x[24];
      perm_ain[ 8] = x[17];
      perm_ain[ 9] = x[18];
      perm_ain[10] = x[19];
      perm_ain[11] = x[20];
      perm_ain[12] = x[21];
      perm_ain[13] = x[22];
      perm_ain[14] = x[23];
      perm_ain[15] = x[16];
      perm_ain[16] = x[ 9];
      perm_ain[17] = x[10];
      perm_ain[18] = x[11];
      perm_ain[19] = x[12];
      perm_ain[20] = x[13];
      perm_ain[21] = x[14];
      perm_ain[22] = x[15];
      perm_ain[23] = x[ 8];
      perm_ain[24] = x[ 1];
      perm_ain[25] = x[ 2];
      perm_ain[26] = x[ 3];
      perm_ain[27] = x[ 4];
      perm_ain[28] = x[ 5];
      perm_ain[29] = x[ 6];
      perm_ain[30] = x[ 7];
      perm_ain[31] = x[ 0];
    end
  endfunction
  function [31:0] perm_mb;
    input [31:0] x;
    begin
      perm_mb[ 0] = x[12];
      perm_mb[ 1] = x[10];
      perm_mb[ 2] = x[14];
      perm_mb[ 3] = x[ 9];
      perm_mb[ 4] = x[13];
      perm_mb[ 5] = x[11];
      perm_mb[ 6] = x[15];
      perm_mb[ 7] = x[ 8];
      perm_mb[ 8] = x[20];
      perm_mb[ 9] = x[18];
      perm_mb[10] = x[22];
      perm_mb[11] = x[17];
      perm_mb[12] = x[21];
      perm_mb[13] = x[19];
      perm_mb[14] = x[23];
      perm_mb[15] = x[16];
      perm_mb[16] = x[28];
      perm_mb[17] = x[26];
      perm_mb[18] = x[30];
      perm_mb[19] = x[25];
      perm_mb[20] = x[29];
      perm_mb[21] = x[27];
      perm_mb[22] = x[31];
      perm_mb[23] = x[24];
      perm_mb[24] = x[ 4];
      perm_mb[25] = x[ 2];
      perm_mb[26] = x[ 6];
      perm_mb[27] = x[ 1];
      perm_mb[28] = x[ 5];
      perm_mb[29] = x[ 3];
      perm_mb[30] = x[ 7];
      perm_mb[31] = x[ 0];
    end
  endfunction
  function [31:0] perm_md;
    input [31:0] x;
    begin
      perm_md[ 0] = x[ 0];
      perm_md[ 1] = x[ 4];
      perm_md[ 2] = x[ 2];
      perm_md[ 3] = x[ 6];
      perm_md[ 4] = x[ 1];
      perm_md[ 5] = x[ 5];
      perm_md[ 6] = x[ 3];
      perm_md[ 7] = x[ 7];
      perm_md[ 8] = x[24];
      perm_md[ 9] = x[28];
      perm_md[10] = x[26];
      perm_md[11] = x[30];
      perm_md[12] = x[25];
      perm_md[13] = x[29];
      perm_md[14] = x[27];
      perm_md[15] = x[31];
      perm_md[16] = x[16];
      perm_md[17] = x[20];
      perm_md[18] = x[18];
      perm_md[19] = x[22];
      perm_md[20] = x[17];
      perm_md[21] = x[21];
      perm_md[22] = x[19];
      perm_md[23] = x[23];
      perm_md[24] = x[ 8];
      perm_md[25] = x[12];
      perm_md[26] = x[10];
      perm_md[27] = x[14];
      perm_md[28] = x[ 9];
      perm_md[29] = x[13];
      perm_md[30] = x[11];
      perm_md[31] = x[15];
    end
  endfunction
  function [31:0] perm_iain;
    input [31:0] x;
    begin
      perm_iain[ 0] = x[31];
      perm_iain[ 1] = x[24];
      perm_iain[ 2] = x[25];
      perm_iain[ 3] = x[26];
      perm_iain[ 4] = x[27];
      perm_iain[ 5] = x[28];
      perm_iain[ 6] = x[29];
      perm_iain[ 7] = x[30];
      perm_iain[ 8] = x[23];
      perm_iain[ 9] = x[16];
      perm_iain[10] = x[17];
      perm_iain[11] = x[18];
      perm_iain[12] = x[19];
      perm_iain[13] = x[20];
      perm_iain[14] = x[21];
      perm_iain[15] = x[22];
      perm_iain[16] = x[15];
      perm_iain[17] = x[ 8];
      perm_iain[18] = x[ 9];
      perm_iain[19] = x[10];
      perm_iain[20] = x[11];
      perm_iain[21] = x[12];
      perm_iain[22] = x[13];
      perm_iain[23] = x[14];
      perm_iain[24] = x[ 7];
      perm_iain[25] = x[ 0];
      perm_iain[26] = x[ 1];
      perm_iain[27] = x[ 2];
      perm_iain[28] = x[ 3];
      perm_iain[29] = x[ 4];
      perm_iain[30] = x[ 5];
      perm_iain[31] = x[ 6];
    end
  endfunction
  function [31:0] perm_imb;
    input [31:0] x;
    begin
      perm_imb[ 0] = x[31];
      perm_imb[ 1] = x[27];
      perm_imb[ 2] = x[25];
      perm_imb[ 3] = x[29];
      perm_imb[ 4] = x[24];
      perm_imb[ 5] = x[28];
      perm_imb[ 6] = x[26];
      perm_imb[ 7] = x[30];
      perm_imb[ 8] = x[ 7];
      perm_imb[ 9] = x[ 3];
      perm_imb[10] = x[ 1];
      perm_imb[11] = x[ 5];
      perm_imb[12] = x[ 0];
      perm_imb[13] = x[ 4];
      perm_imb[14] = x[ 2];
      perm_imb[15] = x[ 6];
      perm_imb[16] = x[15];
      perm_imb[17] = x[11];
      perm_imb[18] = x[ 9];
      perm_imb[19] = x[13];
      perm_imb[20] = x[ 8];
      perm_imb[21] = x[12];
      perm_imb[22] = x[10];
      perm_imb[23] = x[14];
      perm_imb[24] = x[23];
      perm_imb[25] = x[19];
      perm_imb[26] = x[17];
      perm_imb[27] = x[21];
      perm_imb[28] = x[16];
      perm_imb[29] = x[20];
      perm_imb[30] = x[18];
      perm_imb[31] = x[22];
    end
  endfunction
  function [31:0] perm_imd;
    input [31:0] x;
    begin
      perm_imd[ 0] = x[ 0];
      perm_imd[ 1] = x[ 4];
      perm_imd[ 2] = x[ 2];
      perm_imd[ 3] = x[ 6];
      perm_imd[ 4] = x[ 1];
      perm_imd[ 5] = x[ 5];
      perm_imd[ 6] = x[ 3];
      perm_imd[ 7] = x[ 7];
      perm_imd[ 8] = x[24];
      perm_imd[ 9] = x[28];
      perm_imd[10] = x[26];
      perm_imd[11] = x[30];
      perm_imd[12] = x[25];
      perm_imd[13] = x[29];
      perm_imd[14] = x[27];
      perm_imd[15] = x[31];
      perm_imd[16] = x[16];
      perm_imd[17] = x[20];
      perm_imd[18] = x[18];
      perm_imd[19] = x[22];
      perm_imd[20] = x[17];
      perm_imd[21] = x[21];
      perm_imd[22] = x[19];
      perm_imd[23] = x[23];
      perm_imd[24] = x[ 8];
      perm_imd[25] = x[12];
      perm_imd[26] = x[10];
      perm_imd[27] = x[14];
      perm_imd[28] = x[ 9];
      perm_imd[29] = x[13];
      perm_imd[30] = x[11];
      perm_imd[31] = x[15];
    end
  endfunction

  function [31:0] subbytes;
    input [31:0] s;
    begin
      subbytes = {sbox(s[31:24]), sbox(s[23:16]), sbox(s[15:8]), sbox(s[7:0])};
    end
  endfunction

  function [31:0] isubbytes;
    input [31:0] s;
    begin
      isubbytes = {isbox(s[31:24]), isbox(s[23:16]), isbox(s[15:8]), isbox(s[7:0])};
    end
  endfunction

  // Combinational round functions (encrypt and decrypt directions).
  wire [31:0] enc_first = perm_ain(shreg) ^ KEY;            // x0 = Ain(P)^K
  wire [31:0] enc_round = perm_mb(subbytes(state)) ^ KEY;   // x_{t+1}
  wire [31:0] enc_last  = perm_md(subbytes(state));         // C = Md(S(x3))

  wire [31:0] dec_first = isubbytes(perm_imd(shreg));            // x3
  wire [31:0] dec_round = isubbytes(perm_imb(state ^ KEY));      // x_{t-1}
  wire [31:0] dec_last  = perm_iain(state ^ KEY);                // P

  always @(posedge SCK) begin
    if (!RST_N) begin
      shreg <= 32'd0;
      state <= 32'd0;
      cnt   <= 3'd0;
      busy  <= 1'b0;
      MISO  <= 1'b0;
    end else begin
      // --- SPI shift register (only when selected and idle) ---
      if (!NORM_CS_N) begin
        MISO  <= shreg[31];
        shreg <= {shreg[30:0], MOSI};
      end

      // --- crypto FSM: BUSY for exactly 4 SCK cycles ---
      if (cnt == 3'd0) begin
        if (START) begin
          state <= ENC_DEC ? dec_first : enc_first;
          cnt   <= 3'd1;
          busy  <= 1'b1;
        end
      end else if (cnt < 3'd4) begin
        state <= ENC_DEC ? dec_round : enc_round;
        cnt   <= cnt + 3'd1;
      end else begin  // cnt == 4: final round, latch result for read-out
        shreg <= ENC_DEC ? dec_last : enc_last;
        busy  <= 1'b0;
        cnt   <= 3'd0;
      end
    end
  end

endmodule
`default_nettype wire

